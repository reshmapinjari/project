﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using blob.Reporsities;

namespace blob.Controllers
{
    public class BlobController : Controller
    {
        private readonly IAzureStorageReporistory repo;
        public BlobController(IAzureStorageReporistory _repo)
        {
            this.repo = _repo;
        }
        // GET: Blob
        public ActionResult Index()
        {
            
            var blobVM = repo.GetBlobs();
            return View(blobVM);
        }
        public JsonResult RemoveBlob(string file, string extension) {
            bool isDeleted = repo.DeleteBlob(file, extension);
            return Json(isDeleted, JsonRequestBehavior.AllowGet);
        }
        public async Task<ActionResult> DownloadBlob(string file, string fileExtension) {
            bool isDownloaded =await repo.DownloadBlobAsync(file, fileExtension);
            return RedirectToAction("index");
        }
        [HttpGet]
        public ActionResult UploadBlob()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadBlob(HttpPostedFileBase Uploadfile)
        {
            bool isuploaded = repo.UploadBlob(Uploadfile);
            if (isuploaded == true)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}