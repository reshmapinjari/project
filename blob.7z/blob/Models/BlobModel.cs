﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace blob.Models
{
    public class BlobModel
    {
        public string BlobContainerName { get; set; }
        public string StorageUrl { get; set; }
        public string ActualFileName { get; set; }
        public string PrimaryUrl { get; set; }
        public string fileExtension { get; set; }

        public string FileNameWithoutExt
        {
            get
            {
                return Path.GetFileNameWithoutExtension(ActualFileName);
            }
        }
            public string FileNmaeExtensionOnly
            {
            get
            {
                return System.IO.Path.GetExtension(ActualFileName).Substring(1);
            }
            }
        
    }
}
