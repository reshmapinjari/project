﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using blob.Models;
using System.Threading.Tasks;

namespace blob.Reporsities
{
    public class IAzureStorageReporistory
    {
        IEnumerable<BlobModel> GetBlobs();
        bool DeleteBlob(string file,string fileExtension);
        bool UploadBlob(HttpPostedFileBase blobFile);
        Task<bool>Download(string file,string fileExtension);
    }
}