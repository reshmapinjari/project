﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using blob.Models;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Auth;

namespace blob.Reporsities
{
    public class BlobStorageRepository:IAzureStorageReporistory
    {
        private StorageCredentials _storageCredentialsx;
        private CloudStorageAccount _cloudStorageAccountx;
        private CloudBlobClient _cloudBlobClientx;
        private CloudBlobContainer _cloudBlobContainerx;


        private string ContainerNmaex = "";
        private string downloadpath = @"c:\AZ\";
        public BlobStorageRepository() {

            string accountNamex = "";
            string keyx = "";
            _storageCredentialsx = new StorageCredentials(accountNamex, keyx);
            _cloudStorageAccountx = new CloudStorageAccount(_storageCredentialsx, true);
            _cloudBlobClientx = _cloudStorageAccountx.CreateCloudBlobClient();
            _cloudBlobContainerx = _cloudBlobContainerx.GetContainerReference(ContainerNmaex);

        }
        public bool DeleteBlob(string file, string fileExtension) 
        {
            _cloudBlobContainerx=_cloudBlobContainerx.GetContainerReference(ContainerNmaex);
            CloudBlockBlob blockBlob = _cloudBlobContainerx.GetBlockBlobReference(file + "." + fileExtension);
            bool deleted = blockBlob.DeleteIfExists();
            return true;
            //throw new NotImplementedException();
        }

        public async Task<bool> DownloadBlob(string file, string fileExtension)
        {
            _cloudBlobContainerx = _cloudBlobContainerx.GetContainerReference(ContainerNmaex);
            CloudBlockBlob blockBlob = _cloudBlobContainerx.GetBlockBlobReference(file + "." + fileExtension);

            using (var fileStream = System.IO.File.OpenWrite(downloadpath + file + "." + fileExtension))
            {
                await blockBlob.DownloadToStreamAsync(fileStream);
            }//throw new NotImplementedException();
        }
        public IEnumerable<BlobModel> GetBlobs()
        {
            var context = _cloudBlobContainerx.ListBlobs().ToList();
            IEnumerable<BlobModel> VM = context.Select(x => new BlobModel
            {
                BlobContainerName = x.Container.Name,
                StorageUrl = x.StorageUri.PrimaryUri.ToString(),
                PrimaryUrl = x.StorageUri.PrimaryUri.ToString(),
                ActualFileName = x.Uri.AbsoluteUri.Substring(x.Uri.AbsoluteUri.LastIndexOf("/") + 1),
                fileExtension = System.IO.Path.GetExtension(x.Uri.AbsoluteUri.Substring(x.Uri.AbsoluteUri.LastIndexOf("/") + 1))
            }).ToList();
            return VM;
        }
        public bool UploadBlob(HttpPostedFileBase blobFile)
        {
            if (blobFile == null) {
                return false;
            }
            _cloudBlobContainerx = _cloudBlobContainerx.GetContainerReference(ContainerNmaex);
            CloudBlockBlob blockBlob = _cloudBlobContainerx.GetBlockBlobReference(blobFile.FileName);
            using (var filestream = (blobFile.InputStream))
            {
                blockBlob.UploadFromStream(filestream);

            }
            return true;
            //throw new NotImplementedException();
        }
    }
}